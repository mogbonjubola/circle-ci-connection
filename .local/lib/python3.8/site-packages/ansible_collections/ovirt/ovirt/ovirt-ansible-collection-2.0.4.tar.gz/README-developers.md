README for developers
====================================

You can find all information around [development](https://github.com/oVirt/ovirt-ansible-collection/wiki/Development) or [project structure](https://github.com/oVirt/ovirt-ansible-collection/wiki/Project-structure) in [wiki](https://github.com/oVirt/ovirt-ansible-collection/wiki).
