Continuous Integration Scripts
==============================

This directory contains scripts for Continuous Integration provided by
[oVirt Jenkins](http://jenkins.ovirt.org/)
system and follows the standard defined in
[Build and test standards](http://www.ovirt.org/CI/Build_and_test_standards)
wiki page.
